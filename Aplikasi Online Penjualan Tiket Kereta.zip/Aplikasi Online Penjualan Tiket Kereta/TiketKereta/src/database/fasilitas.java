/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import com.mysql.jdbc.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author Ravi Rizki Ramdhani
 */
public class fasilitas {

    private Connection koneksi;
    private String ReportPath = "report/";

    public fasilitas() {
        koneksi = controller.koneksi.getKoneksi();
    }

    public void insert(tiket tiket) {
        PreparedStatement prepare = null;
        try {
            String sql = "INSERT INTO tiket_kereta(jurusan, jenis, harga, no_kursi,nama_penumpang, jumlah_tiket, total_bayar)VALUES(?,?,?,?,?,?,?)";
            prepare = (PreparedStatement) koneksi.prepareStatement(sql);
            prepare.setString(1, tiket.getJurusan());
            prepare.setString(2, tiket.getJenis());
            prepare.setLong(3, tiket.getHarga());
            prepare.setInt(4, tiket.getNo_kursi());
            prepare.setString(5, tiket.getNama_penumpang());
            prepare.setLong(6, tiket.getJumlah_tiket());
            prepare.setInt(7, tiket.getTotal_bayar());
            prepare.executeUpdate();
            System.out.println("Prepare statement berhasil dibuat");
        } catch (SQLException ex) {
            System.out.println("Prepare statement gagal dibuat");
            System.out.println("Pesan : " + ex.getMessage());
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                    System.out.println("Prepare statemen berhasil ditutup");
                } catch (SQLException ex) {
                    System.out.println("Prepare statemen gagal ditutup");
                    System.out.println("Pesan : " + ex.getMessage());
                }
            }
        }
    }

    public void update(tiket tiket) {
        PreparedStatement prepare = null;
        try {
            String sql = "UPDATE tiket_kereta SET jurusan=?,jenis=?,harga=?,no_kursi=?,nama_penumpang=?,jumlah_tiket=?,total_bayar=? WHERE jurusan=?";
            prepare = (PreparedStatement) koneksi.prepareStatement(sql);
            prepare.setString(1, tiket.getJurusan());
            prepare.setString(2, tiket.getJenis());
            prepare.setLong(3, tiket.getHarga());
            prepare.setInt(4, tiket.getNo_kursi());
            prepare.setString(5, tiket.getNama_penumpang());
            prepare.setLong(6, tiket.getJumlah_tiket());
            prepare.setInt(7, tiket.getTotal_bayar());
            prepare.executeUpdate();
            System.out.println("Prepare statement berhasil dibuat");
        } catch (SQLException ex) {
            System.out.println("Prepare statement gagal dibuat");
            System.out.println("Pesan : " + ex.getMessage());
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                    System.out.println("Prepare statemen berhasil ditutup");
                } catch (SQLException ex) {
                    System.out.println("Prepare statemen gagal ditutup");
                    System.out.println("Pesan : " + ex.getMessage());
                }
            }
        }
    }

    public void delete(String jurusan) {
        PreparedStatement prepare = null;
        try {
            String sql = "DELETE FROM tiket_kereta WHERE jurusan=?";
            prepare = (PreparedStatement) koneksi.prepareStatement(sql);
            prepare.setString(1, jurusan);
            prepare.executeUpdate();
            System.out.println("Prepare statement berhasil dibuat");
        } catch (SQLException ex) {
            System.out.println("Prepare statement gagal dibuat");
            System.out.println("Pesan : " + ex.getMessage());
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                    System.out.println("Prepare statemen berhasil ditutup");
                } catch (SQLException ex) {
                    System.out.println("Prepare statemen gagal ditutup");
                    System.out.println("Pesan : " + ex.getMessage());
                }
            }
        }
    }

    public List<tiket> selectAll() {
        PreparedStatement prepare = null;
        ResultSet result = null;
        List<tiket> list = new ArrayList<>();
        String sql = "SELECT * FROM tiket_kereta";
        try {
            prepare = (PreparedStatement) koneksi.prepareStatement(sql);
            result = prepare.executeQuery();
            while (result.next()) {

                tiket tiket = new tiket();
                tiket.setJurusan(result.getString("jurusan"));
                tiket.setJenis(result.getString("jenis"));
                tiket.setHarga(result.getLong("harga"));
                tiket.setNo_kursi(result.getInt("no_kursi"));
                tiket.setNama_penumpang(result.getString("nama_penumpang"));
                tiket.setJumlah_tiket(result.getLong("jumlah_tiket"));
                tiket.setTotal_bayar(result.getInt("total_bayar"));
                list.add(tiket);
            }

            System.out.println("Prepare statement berhasil dibuat");
            return list;

        } catch (SQLException ex) {
            System.out.println("Prepare statement gagal dibuat");
            System.out.println("Pesan : " + ex.getMessage());
            return list;

        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                    System.out.println("Prepare statemen berhasil ditutup");
                } catch (SQLException ex) {
                    System.out.println("Prepare statemen gagal ditutup");
                    System.out.println("Pesan : " + ex.getMessage());
                }
            }
            if (result != null) {
                try {
                    result.close();
                    System.out.println("Resultset berhasil ditutup");
                } catch (SQLException ex) {
                    System.out.println("Resultset gagal ditutup");
                    System.out.println("Pesan : " + ex.getMessage());
                }
            }
        }
    }

    public void viewReport() {
        String reportSource;
        String reportDest;
        reportSource = "E:\\Aplikasi Online Penjualan Tiket Kereta\\TiketKereta\\src\\report\\laporan\\DATA_TIKET_KERETA.jrxml";
        reportDest = "E:\\Aplikasi Online Penjualan Tiket Kereta\\TiketKereta\\src\\report\\laporan\\DATA_TIKET_KERETA.html";
        try {
            JasperReport jasperReport = JasperCompileManager.compileReport(reportSource);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null,
                    koneksi);
            JasperExportManager.exportReportToHtmlFile(jasperPrint, reportDest);
            JasperViewer.viewReport(jasperPrint, false);
        } catch (JRException e) {
            e.getStackTrace();
        }
    }
}
