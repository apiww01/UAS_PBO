/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import com.stripbandunk.jwidget.annotation.TableColumn;

/**
 *
 * @author Ravi Rizki Ramdhani
 */
public class tiket {

    @TableColumn(number = 1, name = "JURUSAN")
    private String jurusan;
    @TableColumn(number = 2, name = "JENIS")
    private String jenis;
    @TableColumn(number = 3, name = "HARGA")
    private long harga;
    @TableColumn(number = 4, name = "NO.KURSI")
    private int no_kursi;
    @TableColumn(number = 5, name = "NAMA PENUMPANG")
    private String nama_penumpang;
    @TableColumn(number = 6, name = "JUMLAH TIKET")
    private long jumlah_tiket;
    
    private int total_bayar;

    public String getJurusan() {
        return jurusan;
    }

    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public long getHarga() {
        return harga;
    }

    public void setHarga(long harga) {
        this.harga = harga;
    }

    public int getNo_kursi() {
        return no_kursi;
    }

    public void setNo_kursi(int no_kursi) {
        this.no_kursi = no_kursi;
    }

    public String getNama_penumpang() {
        return nama_penumpang;
    }

    public void setNama_penumpang(String nama_penumpang) {
        this.nama_penumpang = nama_penumpang;
    }

    public long getJumlah_tiket() {
        return jumlah_tiket;
    }

    public void setJumlah_tiket(long jumlah_tiket) {
        this.jumlah_tiket = jumlah_tiket;
    }

    public int getTotal_bayar() {
        return total_bayar;
    }

    public void setTotal_bayar(int total_bayar) {
        this.total_bayar = total_bayar;
    }

}
